package hilos;

public class Hilos {

    public static void main(String[] args) {
        
        Hilo h1 = new Hilo("Hilo 1", (int)(Math.random()*2000));
        Hilo h2 = new Hilo("Hilo 2", (int)(Math.random()*2000));
        
        h1.start();
        h2.start();
        
        System.out.println(h1);
        System.out.println(h2);
    }
    
}
